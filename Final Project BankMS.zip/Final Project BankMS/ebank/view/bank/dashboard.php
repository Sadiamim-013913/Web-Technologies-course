<?php
echo"<p class='boldline'>Dashboard</p>";
echo "<p class='boldline'><a href='../../index.html'>Go Back</a></p>";
?>