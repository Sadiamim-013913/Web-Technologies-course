<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="style.css">
</head>


<body>
    <div class="foot">
        <div class="fleft">
            <h4>About us us:</h4>

            <hr>
        </div>
        <div class="fmid">
            <h4>Follow us:</h4>

            <hr> facebook <br> instagram <br> github <br>
        </div>
        <div class="fright">
            <h4>Contuc us:</h4>
            <hr>
            <p>Address: G4 388 Bashundhara Dhaka, BD 10013 Bangladesh. <br> The G4 Private Bank G4group Center 153 East 53rd Street 16/ F, Zone 19 Dhaka,<br> BD 10022 Bangladesh. <br>
            </p>
        </div>
        <center><h4>Copyright c 2021 G4group, Inc.</h4></center>
    </div>
</body>

</html>